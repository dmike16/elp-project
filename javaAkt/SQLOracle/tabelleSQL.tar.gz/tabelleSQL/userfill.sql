INSERT INTO users (id,user_name,password,fullname,email,salary,user_type) VALUES (1,'bill','passKel','Billy','bill@yahoo.com',1234.44,23);
INSERT INTO users (id,user_name,password,fullname,email,salary,user_type) VALUES (2,'manzikic','kode34r','Mario','not@yahoo.com',534.44,21);
INSERT INTO users (id,user_name,password,fullname,email,salary,user_type) VALUES (3,'trott','ppasskkL34','Jhon','jhon33@gmail.com',534.44,21);
INSERT INTO users (id,user_name,password,fullname,email,salary,user_type) VALUES (4,'slash','koro23e3','Romanov','tgt@yahoo.com',134.44,10);
INSERT INTO users (id,user_name,password,fullname,email,salary,user_type) VALUES (5,'momo','z24orro','Monkey','momo@yahoo.com',234.44,10);