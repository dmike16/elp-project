INSERT INTO users_type (user_type,description) VALUES (23,'SYSDBA');
INSERT INTO users_type (user_type,description) VALUES (21,'CLIENT');
INSERT INTO users_type (user_type,description) VALUES (22,'SERVER');
INSERT INTO users_type (user_type,description) VALUES (10,'Guest');