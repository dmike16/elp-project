package cipolla;

public enum FormatDate {
	DDMMYY,MMDDYY,YYMMDD
}
